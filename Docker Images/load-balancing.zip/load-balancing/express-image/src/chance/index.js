var Chance = require('chance');
var chance = new Chance();

console.log('Bonjour ' + chance.name());
